config.baseUrl = '..';
require.config(config);
