module.exports = {
    'extends': '../react/.eslintrc.js'
};
