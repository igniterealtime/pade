# Voice Message plugin for converse.js

<img src="https://github.com/conversejs/community-plugins/blob/master/packages/vmsg/vmsg.png" />

## Overview
This plugin creates and uploads an mp3 voice message file for Converse using [this project](https://github.com/addpipe/simple-vmsg-demo).

## Install
see https://m.conversejs.org/docs/html/plugin_development.html on how to install this plugin. Please note that the plugin has a dependency on loading the the wasm binary and other dependency files from a relative path called vmsg. Edit the plugin code if otherwise.

## How to use
Click on disk icon on the conversation toolbar to display the modal form
