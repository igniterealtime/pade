# Stickers plugin for converse.js

<img src="https://github.com/conversejs/community-plugins/blob/master/packages/stickers/stickers.png" />

## Overview
This plugin uses the custom emojis place holder in Converse to provide stickers. See [emoji_categories documentation](https://conversejs.org/docs/html/configuration.html#emoji-categories) for more details

## Install
See https://m.conversejs.org/docs/html/plugin_development.html on how to install this plugin

See index.html for example usage

## How to use
Click on the smiling cup icon in the emojis dialog to view and select a sticker
