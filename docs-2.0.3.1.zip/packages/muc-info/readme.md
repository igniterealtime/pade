# Toolbar utilities plugin for converse.js

<img src="https://github.com/conversejs/community-plugins/blob/master/packages/info/muc-info.png" />

## Overview
This plugin adds a sidebar for groupchat.

## Install
See https://m.conversejs.org/docs/html/plugin_development.html on how to install this plugin

See index.html for example usage

## How to use
Click on the appropriate icon to perform the associated action.
