# MUC Directory plugin for converse.js

<img src="https://github.com/conversejs/community-plugins/blob/master/packages/muc-directory/muc-directory.png" />

## Overview
This plugin scans the contacts roster and does a service discovery on every XMPP domain found. It creates creates a tiled list of all MUC public chat rooms found. Click on any of the tiles to open the selected chat room.

## Install
see https://m.conversejs.org/docs/html/plugin_development.html on how to install this plugin

## How to use
Click on the tile icon next to GROUPCHATS in the control toolbar to display the modal form
