This folder is the location of the documentation of P�d� at https://igniterealtime.github.io/Pade/

Please submit pull requests to help finish the documentation