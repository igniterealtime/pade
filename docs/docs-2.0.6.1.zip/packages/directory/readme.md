# User Directory Search plugin for converse.js

<img src="https://github.com/conversejs/community-plugins/blob/master/packages/directory/directory.png" />

## Overview
This plugin implements [XMPP search](https://xmpp.org/extensions/xep-0055.html). Click on any of the links returned to open a chatbox window and add the person as a contact.

## Install
see https://m.conversejs.org/docs/html/plugin_development.html on how to install this plugin

## How to use
Click on the male/female icon on the conversation toolbar to display the modal form
