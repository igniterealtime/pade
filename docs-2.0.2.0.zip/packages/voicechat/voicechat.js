(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        define(["converse"], factory);
    } else {
        factory(converse);
    }
}(this, function (converse) {
    var _converse, html, __;

	converse.plugins.add("voicechat", {
		dependencies: [],

		initialize: function () {
            _converse = this._converse;
            html = converse.env.html;
            __ = _converse.__;

			_converse.api.settings.update({
				voicechat: {
					hosts: {
						domain: 'pade.chat',
						muc: 'conference.pade.chat'
					},					
					serviceUrl: 'wss://pade.chat:5443/ws/'
				}
			});

			_converse.api.listen.on('parseMessage', async (stanza, attrs) => {
				return parseStanza(stanza, attrs);
			});	
			
			_converse.api.listen.on('parseMUCMessage', async (stanza, attrs) => {
				return parseStanza(stanza, attrs);
			});
			
			_converse.api.listen.on('message', (data) => {			
				if (!data.attrs.json) return;
				console.log("voicechat", data.attrs.json);
			});
			
            _converse.api.listen.on('callButtonClicked', function(data) {
				const model = data.model;
				const type = (model.get('type') == 'chatroom') ? 'groupchat' : 'chat';
				const target = model.get('jid');
				const room = type + '-' + converse.env.Strophe.getNodeFromJid(target);
				const view = _converse.chatboxviews.get(target);
				const button = view.querySelector('.toggle-call converse-icon');
				const url = _converse.api.settings.get('voicechat').serviceUrl;
				const json = {url, room};
				console.log("voicechat is clicked", button, json);

				if (button.classList.contains('blink_me')) {
					button.classList.remove('blink_me');
					json.action = 'stopVoiceChat';
				} else {
					json.action = 'startVoiceChat';					
					button.classList.add('blink_me');					
				}
				_converse.api.send($msg({to: target, from: data.connection.jid, type}).c("json", {'xmlns': 'urn:xmpp:json:0'}).t(JSON.stringify(json)));				
				
            });

            _converse.api.listen.on('chatRoomViewInitialized', function (model)
            {
                console.debug("chatRoomViewInitialized", model);
			});
			
            _converse.api.listen.on('chatBoxViewInitialized', function (model)
            {
                console.debug("chatBoxViewInitialized", model);
			});
			
            _converse.api.listen.on('chatBoxClosed', function (model)
            {
                console.debug("chatBoxClosed", model);
            });			
			
			console.log("voicechat plugin is ready");
		} // 
	});

	async function parseStanza(stanza, attrs) {
		const json = stanza.querySelector('json');

		if (json) {
			attrs.json = JSON.parse(json.innerHTML);		
			console.log("parseStanza", stanza, attrs);		
		}
		return attrs;
	}
	
}));
